package com.example.milanuncios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MilanunciosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MilanunciosApplication.class, args);
	}

}
